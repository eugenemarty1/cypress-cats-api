// a command to get cats' info via API

Cypress.Commands.add('getCatsDetails', (breed) => {
  cy.request({
    method: 'GET',
    url: 'https://api-ninjas.com/api/cats',
    headers: {
      'X-Api-Key': 'ZtBnKV26rhhN2pbiQ1CzZQ==IpdTHudrfI7afeAw',
    },
  });
});
