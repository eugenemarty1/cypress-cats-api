describe('Get Cats Details via API', () => {
  const breedName = 'Abyssinian';

  it(`Should get cat breedName '${breedName}' by "name" parameter and return 200 status code.`, () => {
    cy.getCatDetails(breedName).then((response) => {
      expect(response.status).to.equal(200);
    });
  });

  // fetch by a different breed
  const americanBreed = 'American';
  it(`Should get cat breedName '${americanBreed}' by "name" parameter and return 200 status code.`, () => {
    cy.getCatDetails(americanBreed).then((response) => {
      expect(response.status).to.equal(200);
    });
  });

  it(`Should get properties from API response of '${breedName}' cat and confirm they're returned correctly w/ correct data types.`, () => {
    cy.getCatDetails(breedName).then((response) => {
      // cy.task('log', response); (enable for debugging)
      response.body.forEach((key) => {
        expect(key).to.have.property('length');
        expect(key).to.have.property('name').that.is.a('string');
        expect(key).to.have.property('name').to.equal(breedName); // explicitly check that name matches
        expect(key).to.have.property('origin').that.is.a('string');
        expect(key).to.have.property('image_link').that.is.a('string');
        expect(key).to.have.property('shedding').that.is.a('number');
        expect(key).to.have.property('general_health').that.is.a('number');
        expect(key).to.have.property('playfulness').that.is.a('number');
        expect(key).to.have.property('children_friendly').that.is.a('number');
        expect(key).to.have.property('grooming').that.is.a('number');
        expect(key).to.have.property('intelligence').that.is.a('number');
        expect(key).to.have.property('other_pets_friendly').that.is.a('number');
        expect(key).to.have.property('min_weight').that.is.a('number');
        expect(key).to.have.property('max_weight').that.is.a('number');
        expect(key).to.have.property('min_life_expectancy').that.is.a('number');
        expect(key).to.have.property('max_life_expectancy').that.is.a('number');
      });
    });
  });

  it(`Should get non-existing breed of cat and return a 200 status code, but an empty array.`, () => {
    cy.getCatDetails('non-fsdfsdfsdfsdf').then((response) => {
      expect(response.status).to.equal(200);
      expect(response.body).to.have.length(0);
    });
  });

  it(`Should return 200 status code on empty query parameter.`, () => {
    cy.getCatDetails().then((response) => {
      expect(response.status).to.equal(200);
    });
  });
});
