// a command to get cats' info via API

Cypress.Commands.add('getCatDetails', (breed) => {
  cy.request({
    method: 'GET',
    url: `https://api.api-ninjas.com/v1/cats?name=${breed}`,
    headers: {
      'X-Api-Key': 'ZtBnKV26rhhN2pbiQ1CzZQ==IpdTHudrfI7afeAw',
    },
  });
});
